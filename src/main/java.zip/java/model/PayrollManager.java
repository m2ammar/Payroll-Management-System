package model;

import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;

public class PayrollManager {

    private ArrayList<PaySlip> payrollHistory;
    private YearMonth month;

    public PayrollManager(YearMonth month){

        this.payrollHistory = new ArrayList<>();
        if(month == null){
            throw new IllegalArgumentException("Month can't be null.");
        }else{
            this.month=month;
        }
    }

    public void processMonthly(List<Employee> employees){

        for(Employee employee : employees){
            employee.generate();
        }
    }

    public ArrayList<PaySlip> getPayrollHistory(){
         return this.payrollHistory;
    }

    public YearMonth getMonth(){
        return this.month;
    }
}
